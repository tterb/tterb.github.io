## Install APM packages

You can easily install all of the packages featured on the list by executing the following command:  

```sh
  apm install --packages-file atom-package-list.txt
```
